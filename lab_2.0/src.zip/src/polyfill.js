import setprototypeof from  'setprototypeof';
 
Object.setPrototypeOf = setprototypeof;