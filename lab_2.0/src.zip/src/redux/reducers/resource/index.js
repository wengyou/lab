import { combineReducers } from "redux-immutable";
import resource from "./resource";

export default combineReducers({
    resource,
})