import userMana from "./userSagas";
import resource from "./resourceSagas";
import announce from "./announceSagas";
import course from "./courseSagas";
import admin from './adminSagas';

export default  [userMana, resource, announce, course, admin]
