import React from "react";
import {connect} from "react-redux";
const ImportTemplate = props => {
    return (
        <div>
            admin
        </div>
    )

};
export default connect(
    state => {

    },
    dispatch => {

    },
)(ImportTemplate);