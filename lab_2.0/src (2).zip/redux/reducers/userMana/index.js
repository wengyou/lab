import { combineReducers } from "redux";
import student from "./student.js";
import common from "./common";

export default combineReducers({
    student,
    common
})